numero = 10  
mensaje = "Bienvenido al sistema de cálculo"  
#Inicializamos el resultado en 0
resultado = 0  

#Lista de valores para calcular sus cuadrados
valores = [2, 4, 6, 8, 10]  

print(mensaje)  #Se cambió de 'mensaj' a 'mensaje' que es la variable

#Función para calcular el cuadrado de un número
def cuadrado(n):
    return n ** 2  #Retorna el cuadrado del número

#Inicializamos el índice para el bucle
i = 0  
#Bucle para calcular y mostrar el cuadrado de cada valor en la lista
while i < len(valores):  #Corregimos: 'valore' a 'valores'
    valor_cuadrado = cuadrado(valores[i])  #Correccion: 'valor' a 'valores'
    print("El cuadrado de", valores[i], "es", valor_cuadrado)
    i += 1

#Verificamos si el número es par o impar
if numero % 2 == 0:  #de '=' a '=='
    print("El número es par")
elif numero % 2 == 1:
    print("El número es impar")
else:
    print("Este caso no debería ocurrir")

#Sumamos los valores de la lista y verificar si supera 20
suma = 0  
for numero in valores:  
    suma += numero  #Acumulamos la suma
    if suma > 20:  #Verificamos si la suma supera 20
        print("La suma ha superado 20")
        break  #Salimos del bucle si se supera 20 (rompemos el bucle)

#Definimos una nueva lista
nueva_lista = [5, 7, 9, 11]  
#Imprimimos los valores de la nueva lista
for x in nueva_lista:  #'lista_nueva' a 'nueva_lista'
    print("Valor en nueva lista:", x)

numeros = [10, 20, 30, 40, 50]  
total = 0  
for n in numeros:  
    total += n  #Acumulamos el total
promedio = total / len(numeros)  #Calculamos el promedio
print("El promedio es", promedio)  #corregimos 'promdio' a 'promedio'

contador = 0  #imprime valores del 0 al 4
while contador < 5:  
    print("El contador es", contador)
    contador += 1  #Incrementamos el contador
    if contador == 5:  
        break  #Salimos del bucle si el contador llega a 5
    else:
        print("Contador aún no ha llegado a 5")

edad = 20  
if edad < 18:
    print("Eres menor de edad")
elif edad > 18:
    print("Eres mayor de edad")
else:
    print("Tienes exactamente 18 años")

def suma_numeros(a, b): #Función para sumar dos números
    return a + b  #Retorna la suma de a y b

#Llamada a la función de suma con dos argumentos
resultado_suma = suma_numeros(10, 5)  #se añadio un segundo argumento
print("El resultado de la suma es", resultado_suma)

#Bucle que no se ejecutará porque el rango es incorrecto
for i in range(10, 5):  #Este bucle no se ejecutará
    print("Valor de i:", i)

#Verificación de si un animal está en la lista
animales = ["gato", "perro", "conejo"]  
if "tigre" in animales:  #'animal' a 'animales'
    print("El tigre está en la lista")
else:
    print("El tigre no está en la lista")

#Manejo de excepciones para evitar errores de índice
try:
    print(animales[3])  #Esto generará un error porque no hay un índice 3
except IndexError:
    print("Error: índice fuera de rango")

contador2 = 10  
while contador2 > 0:  
    print("Contador2:", contador2)
    contador2 -= 2  #Decrementamos en 2
    if contador2 == 5:
        print("Contador2 es igual a 5")
        continue  #Continuamos al siguiente ciclo
    else:
        print("Contador2 no es igual a 5")

#Función para verificar si un número está en una lista
def verificar_numero_en_lista(num, lista):
    if num in lista:
        return True  #Retorna True si el número está en la lista
    else:
        return False  #de 'Falso' a 'False' (porque programamos en english)

#Verificamos si el número 10 está en la lista 'numeros'
resultado_verificacion = verificar_numero_en_lista(10, numeros)
print("El número está en la lista:", resultado_verificacion)

#Eliminamos duplicados de una lista
duplicados = [1, 2, 2, 3, 4, 4, 5]  
sin_duplicados = list(set(duplicados))  #conjunto y de nuevo a lista
print("Lista sin duplicados:", sin_duplicados)  #de 'sin_duplicado' a 'sin_duplicados'

#Verificamos la longitud de un texto
texto = "Hola Mundo"  
if len(texto) > 5:  
    print("El texto tiene más de 5 caracteres")
else:
    print("El texto tiene 5 o menos caracteres")

#Definimos un diccionario y mostramos sus claves y valores
diccionario = {"nombre": "Carlos", "edad": 25}  
for clave in diccionario:  #de 'diccionarios' a 'diccionario'
    print("Clave:", clave, "Valor:", diccionario[clave])

#Contador que imprime hasta 5 y se detiene
j = 0  
while j < 10:  
    if j == 5:
        print("Se alcanzó el valor de 5")
        break  #de 'brake' a 'break'
    else:
        j += 1  #Incrementamos j
        continue  #Continuamos al siguiente ciclo
